<?php

$mydb = new PDO('mysql:host=sql106.infinityfree.com;port=3306;dbname=if0_37212468_amazonia', 'if0_37212468', 'aNpojtpHLMeZ');

if ($_GET['abbreviation']) {
    $stmt = $mydb->prepare("SELECT statename AS state, pci, pop AS population, region FROM states WHERE abbrev = :abbreviation AND region <> 'Territory'");
    $stmt->execute([':abbreviation' => strtoupper($_GET['abbreviation'])]);
} elseif (($_GET['statename']) && strlen($_GET['statename']) >= 2) {
    $stmt = $mydb->prepare("SELECT statename AS state, pci, pop AS population, region FROM states WHERE statename LIKE :stateName AND region <> 'Territory'");
    $stmt->execute([':stateName' => "%" . strtolower($_GET['statename']) . "%"]);
}

$state = $stmt->fetch();
if ($state) echo json_encode(['success' => true] + $state);

?>
