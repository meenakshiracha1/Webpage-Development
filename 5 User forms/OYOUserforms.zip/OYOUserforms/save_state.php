<?php

$mydb = new PDO('mysql:host=sql106.infinityfree.com;port=3306;dbname=if0_37212468_amazonia', 'if0_37212468', 'aNpojtpHLMeZ');

$input = json_decode(file_get_contents("php://input"), true);
$abbreviation = $input['abbreviation'];
$state = $input['state'];
$pci = $input['pci'];
$statepop = $input['statepop'];
$region = $input['region'];

if ($abbreviation && $state && $pci && $statepop && $region) {
    $stmt = $mydb->prepare("UPDATE states SET pci = :pci, 
                        pop = :statepop, 
                        region = :region 
                        WHERE statename = :state");
    $stmt->bindParam(":pci", $pci);
    $stmt->bindParam(":statepop", $statepop);
    $stmt->bindParam(":region", $region);
    $stmt->bindParam(":state", $state);
    $stmt->execute();
    
    echo json_encode(["success" => $stmt->rowCount() > 0]);
    return;
}

?>
